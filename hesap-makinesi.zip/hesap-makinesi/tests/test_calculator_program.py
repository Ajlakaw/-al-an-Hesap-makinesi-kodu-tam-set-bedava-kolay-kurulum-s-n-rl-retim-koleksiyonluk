import pytest
from calculate.calculator_program import calculate


def test_calculate_addition():
    assert calculate(1, 1, '+') == 2


def test_calculate_division():
    assert calculate(8, 2, '/') == 4


def test_calculate_unknown_operation():
    assert calculate(5, 5, 'unknown') == "Bilinmeyen işlem."


# Görev için eklenen iki temel birim testi:
def test_calculate_subtraction():
    assert calculate(11, 3, '-') == 8


def test_calculate_multiplication():
    assert calculate(3, 11, '*') == 33


# Farklı durumları kontrol eden ek testler:
def test_calculate_subtraction_negative_result():
    assert calculate(3, 11, '-') == -8


def test_calculate_multiplication_by_zero():
    assert calculate(7, 0, '*') == 0


def test_calculate_division_by_zero():
    assert calculate(7, 0, '/') == "Hata: Sıfıra bölme"


def test_calculate_fractional_division():
    assert calculate(1, 3, '/') == pytest.approx(1 / 3)
