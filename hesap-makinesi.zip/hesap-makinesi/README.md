# Hesap Makinesi Programı

Bu, bir hesap makinesi programıdır.

## Programı Çalıştırma

Programı çalıştırmak için bilgisayarınızda Python 3.6 veya daha üst bir sürümün kurulu olduğundan emin olun.

1. Proje dosyalarını bilgisayarınıza indirin.
2. Terminali veya komut satırını açın.
3. Program dosyalarının bulunduğu dizine/klasöre gidin.
4. Aşağıdaki komutu kullanarak programı çalıştırın:

```bash
python calculator_program.py
```
## Programı Kullanma

Programı başlattıktan sonra, sizden sırasıyla ilk sayıyı, ikinci sayıyı ve bu sayılar arasında yapılacak işlemi girmeniz istenecek. İstenen verileri girdikten sonra Enter tuşuna basın. Program sonucu ekrana yazdıracaktır.

## Programın Çalışmasına Bir Örnek

```bash
İlk sayıyı girin: 4
İkinci sayıyı girin: 3
Yapılacak işlemi seçin (+, -, *, /): +
Sonuç: 7.0
```

## Yazar

Kodland

## Birim Testleri

Projenin kök dizininde `pytest` kurulu değilse önce aşağıdaki komutu çalıştırın:

```bash
python -m pip install pytest
```

Ardından testleri başlatın:

```bash
pytest
```

Testler `tests/test_calculator_program.py` dosyasındadır. Mevcut toplama, bölme ve bilinmeyen işlem testlerine çıkarma, çarpma ve dört farklı durum testi eklenmiştir.
